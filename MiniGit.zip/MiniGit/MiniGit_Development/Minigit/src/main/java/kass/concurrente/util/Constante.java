package kass.concurrente.util;

/**
 * Clase que fungira para almacenar constantes
 * @version 1.0
 * @author Kassandra Mirael
 */
final class Constante {
    private Constante(){}
    
}
