package kass.concurrente.util;

class UtilTest {
    
}
